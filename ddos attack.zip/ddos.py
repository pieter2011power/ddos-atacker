import os
import webbrowser
import time
import validators
import md
from selenium import webdriver








attacks = ('')
website = ('')


website = input ('website url:')

validation = validators.url(website, public=True)
if validation:
  print("TRUE")
  
else:
  print("FALSE URL exit in 10 seconds")
  time.sleep(10)
  exit()

print('loading modules')



time.sleep(10)

os.system('cls')

time.sleep(3)






md.attack()



time.sleep(40)

os.system('cls')

print(website)

print(attacks)

md.after()

time.sleep(10)
exit()
