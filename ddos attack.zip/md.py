def attack():
    import webbrowser
    import time

    mainserver  = ('https://serverat.pieterjansen1.repl.co')
    atserver =  ('https://atserver.pieterjansen1.repl.co')


    print('TRUE')
    time.sleep(3)

    print('CONNECTING TO THE SERVER...')
    webbrowser.open(mainserver)
    print('opening script...')
    time.sleep(5)
    webbrowser.open(atserver)

    time.sleep(5)
    print('server connected')
    time.sleep(3)
def after():
    import os
    import time
    
    py = (os.system('py'))
    oss= ('import os')
    script = (os.system('cls'))
    print('CLEANING PC FROM SERVER ATTACK...')
    time.sleep(3)
    oss
    time.sleep(3)
    script
    time.sleep(2)
    exit()

